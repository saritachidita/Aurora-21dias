import 'package:flutter/material.dart';
import 'dart:convert';
import 'package:flutter/services.dart' show rootBundle;
import '../widgets/voice_player.dart';

class DayViewScreen extends StatefulWidget {
  const DayViewScreen({super.key});

  @override
  State<DayViewScreen> createState() => _DayViewScreenState();
}

class _DayViewScreenState extends State<DayViewScreen> {

  Future<Map<String, dynamic>> _loadConfig() async {
    final text = await rootBundle.loadString('assets/voice_guides/guides_config.json');
    return jsonDecode(text) as Map<String, dynamic>;
  }

  @override
  Widget build(BuildContext context) {
    final args = ModalRoute.of(context)?.settings.arguments as Map<String, dynamic>?;
    final routeName = args?['route'] ?? 'Ruta';
    final day = args?['day'] ?? 1;

    return Scaffold(
      appBar: AppBar(title: Text('$routeName — Día $day de 21')),
      body: FutureBuilder<Map<String, dynamic>>(
        future: _loadConfig(),
        builder: (context, snap) {
          final cfg = snap.data;
          final guide = cfg?['days']['$day'] as String?;
          final defaults = cfg?['route_defaults'] as Map<String, dynamic>?;
          final routeTip = defaults?[routeName] ?? 'Respira. Estás creando tu nueva realidad.';
          return Padding(
            padding: const EdgeInsets.all(20),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text('Mensaje del día', style: Theme.of(context).textTheme.titleLarge),
                const SizedBox(height: 8),
                Text(routeTip),
                const SizedBox(height: 16),
                if (guide != null) VoiceGuidePlayer(asset: guide),
                const SizedBox(height: 24),
                Wrap(
                  spacing: 12,
                  children: [
                    OutlinedButton.icon(
                      onPressed: () => Navigator.pushNamed(context, '/journal'),
                      icon: const Icon(Icons.edit_note),
                      label: const Text('Diario'),
                    ),
                    OutlinedButton.icon(
                      onPressed: () => Navigator.pushNamed(context, '/affirmations'),
                      icon: const Icon(Icons.checklist),
                      label: const Text('Afirmaciones'),
                    ),
                    OutlinedButton.icon(
                      onPressed: () => Navigator.pushNamed(context, '/frequencies'),
                      icon: const Icon(Icons.graphic_eq),
                      label: const Text('Frecuencias'),
                    ),
                  ],
                ),
                const Spacer(),
                Align(
                  alignment: Alignment.bottomRight,
                  child: ElevatedButton(
                    onPressed: () => Navigator.pushReplacementNamed(context, '/day', arguments: {'route': routeName, 'day': day+1}),
                    child: const Text('Completar día'),
                  ),
                )
              ],
            ),
          );
        },
      ),
    );
  }
}
