import 'package:flutter/material.dart';
import '../widgets/audio_player.dart';

class FrequenciesScreen extends StatelessWidget {
  const FrequenciesScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final freqs = [
      {'label':'528 Hz — amor/armonía', 'asset':'assets/frequencies/528hz.mp3'},
      {'label':'396 Hz — liberar miedo', 'asset':'assets/frequencies/396hz.mp3'},
      {'label':'741 Hz — claridad', 'asset':'assets/frequencies/741hz.mp3'},
    ];
    return Scaffold(
      appBar: AppBar(title: const Text('Frecuencias')),
      body: ListView.builder(
        itemCount: freqs.length,
        itemBuilder: (context, i){
          final f = freqs[i];
          return Card(
            margin: const EdgeInsets.all(12),
            child: ListTile(
              title: Text(f['label']!),
              trailing: const Icon(Icons.play_arrow),
              onTap: (){
                Navigator.of(context).push(MaterialPageRoute(builder: (_)=> Scaffold(
                  appBar: AppBar(title: Text(f['label']!)),
                  body: Center(child: AudioPlayerWidget(musicAsset: f['asset']!, voiceAsset: null)),
                )));
              },
            ),
          );
        },
      ),
    );
  }
}
