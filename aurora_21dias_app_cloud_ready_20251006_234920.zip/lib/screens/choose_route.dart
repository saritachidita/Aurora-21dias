import 'package:flutter/material.dart';

class ChooseRouteScreen extends StatefulWidget {
  const ChooseRouteScreen({super.key});

  @override
  State<ChooseRouteScreen> createState() => _ChooseRouteScreenState();
}

class _ChooseRouteScreenState extends State<ChooseRouteScreen> {
  final routes = const ['Amor propio', 'Abundancia', 'Sanación emocional', 'Propósito / claridad'];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Elige tu transformación')),
      body: Padding(
        padding: const EdgeInsets.all(16),
        child: Wrap(
          spacing: 12,
          runSpacing: 12,
          children: routes.map((r) => ChoiceChip(
            label: Text(r),
            selected: false,
            onSelected: (_) => Navigator.pushNamed(context, '/day', arguments: {'route': r, 'day': 1}),
          )).toList(),
        ),
      ),
    );
  }
}
