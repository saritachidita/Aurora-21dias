import 'package:flutter/material.dart';
import '../widgets/audio_player.dart';

class AffirmationsScreen extends StatefulWidget {
  const AffirmationsScreen({super.key});

  @override
  State<AffirmationsScreen> createState() => _AffirmationsScreenState();
}

class _AffirmationsScreenState extends State<AffirmationsScreen> {
  final items = [
    'Yo soy abundancia',
    'Estoy en paz',
    'Confío en el proceso',
  ];
  bool subliminal = false;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Afirmaciones')),
      body: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          children: [
            Expanded(
              child: ListView(
                children: items.map((e) => CheckboxListTile(
                  value: true,
                  onChanged: (_){},
                  title: Text(e),
                )).toList(),
              ),
            ),
            SwitchListTile(
              value: subliminal,
              onChanged: (v)=>setState(()=>subliminal=v),
              title: const Text('Modo subliminal'),
              subtitle: const Text('Mezcla afirmaciones con música/frecuencia a volumen bajo'),
            ),
            const SizedBox(height: 8),
            AudioPlayerWidget(
              musicAsset: 'assets/frequencies/528hz.mp3',
              voiceAsset: 'assets/affirmations/sample_affirmations.mp3',
              subliminalMode: true,
              voiceVolume: subliminal ? 0.2 : 1.0,
            )
          ],
        ),
      ),
    );
  }
}
