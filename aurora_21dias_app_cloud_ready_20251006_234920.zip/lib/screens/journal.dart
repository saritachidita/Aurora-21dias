import 'package:flutter/material.dart';
import '../widgets/recorder.dart';

class JournalScreen extends StatelessWidget {
  const JournalScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final controller = TextEditingController();
    return Scaffold(
      appBar: AppBar(title: const Text('Diario consciente')),
      body: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          children: [
            TextField(
              controller: controller,
              maxLines: 8,
              decoration: const InputDecoration(
                hintText: 'Hoy agradezco...',
                border: OutlineInputBorder(),
              ),
            ),
            const SizedBox(height: 12),
            const RecorderWidget(),
          ],
        ),
      ),
    );
  }
}
