import 'package:flutter/material.dart';
import 'package:just_audio/just_audio.dart';
import 'package:audio_session/audio_session.dart';

class AudioPlayerWidget extends StatefulWidget {
  final String musicAsset;
  final String? voiceAsset;
  final bool subliminalMode;
  final double voiceVolume;

  const AudioPlayerWidget({
    super.key,
    required this.musicAsset,
    this.voiceAsset,
    this.subliminalMode = false,
    this.voiceVolume = 0.4,
  });

  @override
  State<AudioPlayerWidget> createState() => _AudioPlayerWidgetState();
}

class _AudioPlayerWidgetState extends State<AudioPlayerWidget> {
  late final AudioPlayer _music;
  AudioPlayer? _voice;
  bool _playing = false;

  @override
  void initState() {
    super.initState();
    _music = AudioPlayer();
    _setup();
  }

  Future<void> _setup() async {
    final session = await AudioSession.instance;
    await session.configure(const AudioSessionConfiguration.music());
    await _music.setAsset(widget.musicAsset, preload: true);
    if (widget.voiceAsset != null) {
      _voice = AudioPlayer();
      await _voice!.setAsset(widget.voiceAsset!, preload: true);
      _voice!.setVolume(widget.voiceVolume);
    }
  }

  Future<void> _toggle() async {
    if (_playing) {
      await _music.pause();
      if (_voice != null) await _voice!.pause();
    } else {
      await _music.setLoopMode(LoopMode.all);
      await _music.play();
      if (_voice != null) {
        await _voice!.setLoopMode(LoopMode.all);
        await _voice!.play();
      }
    }
    setState(() => _playing = !_playing);
  }

  @override
  void dispose() {
    _music.dispose();
    _voice?.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Column(
      mainAxisSize: MainAxisSize.min,
      children: [
        ElevatedButton.icon(
          onPressed: _toggle,
          icon: Icon(_playing ? Icons.pause : Icons.play_arrow),
          label: Text(_playing ? 'Pausar' : 'Reproducir'),
        ),
        const SizedBox(height: 8),
        if (widget.voiceAsset != null)
          Text('Subliminal: voz mezclada a volumen ${widget.voiceVolume.toStringAsFixed(1)}',
              style: Theme.of(context).textTheme.bodySmall),
      ],
    );
  }
}
