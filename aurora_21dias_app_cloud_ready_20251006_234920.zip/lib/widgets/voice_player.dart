import 'package:flutter/material.dart';
import 'package:just_audio/just_audio.dart';
import 'package:audio_session/audio_session.dart';

class VoiceGuidePlayer extends StatefulWidget {
  final String asset;
  const VoiceGuidePlayer({super.key, required this.asset});

  @override
  State<VoiceGuidePlayer> createState() => _VoiceGuidePlayerState();
}

class _VoiceGuidePlayerState extends State<VoiceGuidePlayer> {
  final _player = AudioPlayer();
  bool _ready = false;

  @override
  void initState() {
    super.initState();
    _setup();
  }

  Future<void> _setup() async {
    final session = await AudioSession.instance;
    await session.configure(const AudioSessionConfiguration.speech());
    try {
      await _player.setAsset(widget.asset, preload: true);
      setState(()=>_ready = true);
    } catch (_) {
      setState(()=>_ready = false);
    }
  }

  @override
  void dispose() {
    _player.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Column(
      mainAxisSize: MainAxisSize.min,
      children: [
        ElevatedButton.icon(
          onPressed: _ready ? () async {
            if (_player.playing) {
              await _player.pause();
            } else {
              await _player.play();
            }
            setState((){});
          } : null,
          icon: Icon(_player.playing ? Icons.pause_circle : Icons.play_circle),
          label: Text(_player.playing ? 'Pausar guía' : 'Escuchar guía (voz)'),
        ),
        if (!_ready)
          const Padding(
            padding: EdgeInsets.only(top: 6),
            child: Text('Coloca tu archivo de guía en assets/voice_guides/', style: TextStyle(fontSize: 12)),
          )
      ],
    );
  }
}
