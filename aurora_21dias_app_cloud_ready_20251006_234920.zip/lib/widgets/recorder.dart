import 'dart:io';
import 'package:flutter/material.dart';
import 'package:record/record.dart';
import 'package:path_provider/path_provider.dart';
import 'package:permission_handler/permission_handler.dart';

class RecorderWidget extends StatefulWidget {
  const RecorderWidget({super.key});

  @override
  State<RecorderWidget> createState() => _RecorderWidgetState();
}

class _RecorderWidgetState extends State<RecorderWidget> {
  final _recorder = AudioRecorder();
  bool _recording = false;
  String? _path;

  Future<String> _tempPath() async {
    final dir = await getApplicationDocumentsDirectory();
    return '${dir.path}/affirmation_${DateTime.now().millisecondsSinceEpoch}.m4a';
  }

  Future<void> _toggleRecord() async {
    if (!_recording) {
      if (await Permission.microphone.request().isGranted) {
        final p = await _tempPath();
        await _recorder.start(const RecordConfig(encoder: AudioEncoder.aacLc), path: p);
        setState(() { _recording = true; _path = p; });
      }
    } else {
      await _recorder.stop();
      setState(() { _recording = false; });
      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('Guardado: $_path')));
    }
  }

  @override
  void dispose() {
    _recorder.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Row(
      children: [
        ElevatedButton.icon(
          onPressed: _toggleRecord,
          icon: Icon(_recording ? Icons.stop : Icons.mic),
          label: Text(_recording ? 'Detener' : 'Grabar reflexión'),
        ),
        const SizedBox(width: 12),
        if (_path != null) Flexible(child: Text('Archivo: ${_path!}', overflow: TextOverflow.ellipsis))
      ],
    );
  }
}
