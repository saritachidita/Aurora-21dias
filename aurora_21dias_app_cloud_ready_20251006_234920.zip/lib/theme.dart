import 'package:flutter/material.dart';

class AppTheme {
  static const Color lavender = Color(0xFFB7A5D6);
  static const Color deepLavender = Color(0xFF7A68A5);
  static const Color gold = Color(0xFFD9C089);
  static const Color pearl = Color(0xFFF7F5F9);

  static ThemeData light() {
    final base = ThemeData.light();
    return base.copyWith(
      scaffoldBackgroundColor: pearl,
      colorScheme: base.colorScheme.copyWith(
        primary: deepLavender,
        secondary: gold,
      ),
      appBarTheme: const AppBarTheme(
        backgroundColor: Colors.white,
        foregroundColor: deepLavender,
        elevation: 0,
      ),
      textTheme: base.textTheme.apply(
        bodyColor: Colors.black87,
        displayColor: deepLavender,
      ),
      elevatedButtonTheme: ElevatedButtonThemeData(
        style: ElevatedButton.styleFrom(
          backgroundColor: gold,
          foregroundColor: Colors.black87,
          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(14)),
          padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 14),
        ),
      ),
      chipTheme: base.chipTheme.copyWith(
        backgroundColor: const Color(0xFFE9E3F5),
        selectedColor: gold,
      ),
    );
  }
}
