import 'package:flutter/material.dart';
import 'theme.dart';
import 'screens/home.dart';
import 'screens/choose_route.dart';
import 'screens/day_view.dart';
import 'screens/journal.dart';
import 'screens/affirmations.dart';
import 'screens/frequencies.dart';
import 'screens/splash_animated.dart';

void main() {
  runApp(const AuroraApp());
}

class AuroraApp extends StatelessWidget {
  const AuroraApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: '21 Días de Transformación',
      theme: AppTheme.light(),
      debugShowCheckedModeBanner: false,
      initialRoute: '/splash',
      routes: {
        '/splash': (_) => const AnimatedSplashScreen(),
        '/': (_) => const HomeScreen(),
        '/choose': (_) => const ChooseRouteScreen(),
        '/day': (_) => const DayViewScreen(),
        '/journal': (_) => const JournalScreen(),
        '/affirmations': (_) => const AffirmationsScreen(),
        '/frequencies': (_) => const FrequenciesScreen(),
      },
    );
  }
}
