# 21 Días de Transformación (Flutter)
Estructura base con: Inicio, Rutas, Día, Diario (texto+voz), Afirmaciones (subliminal), Frecuencias, Splash animado.

## Comandos rápidos
flutter pub get
dart run flutter_launcher_icons
dart run flutter_native_splash:create
flutter run -d web-server --web-hostname 0.0.0.0 --web-port 3000
