// script.js
// Define here the correct password for accessing the diary page. Replace
// "tu_contraseña_secreta" with the password you want to use.
const correctPassword = "tu_contraseña_secreta";

// Handle click on the login button
document.getElementById("login-button").addEventListener("click", function() {
    const entered = document.getElementById("password-input").value;
    if (entered === correctPassword) {
        // If the password is correct, navigate to the diary page
        window.location.href = "diario.html";
    } else {
        // Otherwise, show an alert and stay on the login page
        alert("Contraseña incorrecta, intenta de nuevo.");
    }
});