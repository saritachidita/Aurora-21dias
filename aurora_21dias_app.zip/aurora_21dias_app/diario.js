// diario.js
// Array of affirmations for each day. Feel free to modify or extend
// these messages as desired.
const affirmations = [
    "Día 1: Hoy comienzo mi transformación con energía y compromiso.",
    "Día 2: Soy digno/a de amor, crecimiento y abundancia.",
    "Día 3: Agradezco cada paso que doy hacia mi bienestar.",
    "Día 4: Confío en mi intuición y escucho a mi corazón.",
    "Día 5: Me permito aprender y crecer cada día.",
    "Día 6: Mi mente y mi cuerpo están en armonía.",
    "Día 7: Hoy elijo pensamientos positivos y edificantes.",
    "Día 8: Abrazo mis emociones y las transformo en fuerza.",
    "Día 9: Soy capaz de superar cualquier desafío que se presente.",
    "Día 10: Merezco tiempo para cuidar de mí mismo/a.",
    "Día 11: Celebro mis avances y me perdono mis errores.",
    "Día 12: Estoy construyendo hábitos que apoyan mi mejor versión.",
    "Día 13: Mis metas son claras y trabajo con dedicación para alcanzarlas.",
    "Día 14: Atraigo personas y situaciones que contribuyen a mi crecimiento.",
    "Día 15: Cada día soy más resiliente y adaptable.",
    "Día 16: Mis palabras y acciones reflejan el amor que siento por mí y por los demás.",
    "Día 17: Encuentro belleza y gratitud en lo cotidiano.",
    "Día 18: Mi transformación inspira a otros a transformar sus vidas.",
    "Día 19: Confío en el proceso y me mantengo presente.",
    "Día 20: Me libero de viejas creencias y doy paso a nuevas oportunidades.",
    "Día 21: Hoy celebro mi camino recorrido y sigo adelante con esperanza."
];

// Retrieve the current day from localStorage, defaulting to 1 if not set
let currentDay = parseInt(localStorage.getItem("currentDay") || "1", 10);

// Grab references to page elements
const entryTextarea = document.getElementById("entry");
const dayContent = document.getElementById("day-content");
const prevButton = document.getElementById("prev-day");
const nextButton = document.getElementById("next-day");

// Function to load the affirmation and saved entry for a given day
function loadDay(day) {
    // Display affirmation text
    dayContent.textContent = affirmations[day - 1];
    // Populate the textarea with any saved entry
    entryTextarea.value = localStorage.getItem(`entry_${day}`) || "";
}

// Save the current entry and day to localStorage
function saveEntry() {
    localStorage.setItem(`entry_${currentDay}`, entryTextarea.value);
    localStorage.setItem("currentDay", currentDay);
}

// Navigate to the previous day if possible
prevButton.addEventListener("click", () => {
    if (currentDay > 1) {
        saveEntry();
        currentDay--;
        loadDay(currentDay);
    }
});

// Navigate to the next day if possible
nextButton.addEventListener("click", () => {
    if (currentDay < affirmations.length) {
        saveEntry();
        currentDay++;
        loadDay(currentDay);
    }
});

// Optionally, implement autosave when the user types in the textarea
entryTextarea.addEventListener("input", () => {
    // Uncomment the line below to auto-save on every input
    // saveEntry();
});

// Initialize the page by loading the current day
loadDay(currentDay);